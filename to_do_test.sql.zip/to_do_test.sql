-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Feb 29, 2016 at 10:47 AM
-- Server version: 5.5.42
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `to_do_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories_tasks`
--

CREATE TABLE `categories_tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories_tasks`
--

INSERT INTO `categories_tasks` (`id`, `category_id`, `task_id`) VALUES
(1, 55, 2),
(2, 66, 2),
(3, 67, 33),
(4, 67, 34),
(5, 78, 2),
(6, 89, 2),
(7, 90, 50),
(8, 90, 51),
(9, 11, 2),
(10, 12, 1),
(11, 12, 2),
(12, 23, 2),
(13, 24, 18),
(14, 24, 19),
(15, 35, 2),
(16, 36, 35),
(17, 36, 36),
(18, 47, 2),
(19, 48, 52),
(20, 48, 53),
(21, 59, 69),
(22, 60, 70),
(23, 60, 71),
(24, 71, 87),
(25, 72, 88),
(26, 72, 89),
(27, 83, 105),
(28, 84, 106),
(29, 84, 107),
(30, 95, 123),
(31, 96, 124),
(32, 96, 125),
(33, 107, 141),
(34, 108, 142),
(35, 108, 143),
(36, 119, 159),
(37, 120, 160),
(38, 120, 161),
(39, 134, 179),
(40, 135, 180),
(41, 135, 181),
(42, 136, 197),
(43, 137, 198),
(44, 138, 198),
(45, 147, 199),
(46, 148, 200),
(47, 149, 201),
(48, 149, 202),
(49, 158, 216),
(50, 159, 217),
(51, 160, 218),
(52, 160, 219),
(53, 161, 233),
(54, 162, 234),
(55, 163, 235),
(56, 164, 235),
(58, 174, 237),
(59, 175, 238),
(60, 175, 239),
(62, 177, 254),
(63, 178, 255),
(64, 179, 255),
(66, 189, 257),
(67, 190, 258),
(68, 190, 259),
(70, 192, 274),
(71, 193, 275),
(72, 194, 275),
(74, 204, 277),
(75, 205, 278),
(76, 205, 279),
(78, 207, 294),
(79, 208, 295),
(80, 209, 295);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=210;
--
-- AUTO_INCREMENT for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=296;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
